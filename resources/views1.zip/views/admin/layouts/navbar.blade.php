<!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu">
               
                <div class="sidebar-content">
                    <!--- Sidemenu -->
                    <div id="sidebar-menu" class="slimscroll-menu">


                        <ul class="metismenu" id="menu-bar">
                            <!-- <li class="menu-title">Navigation</li> -->

                            <li>
                                <a href="{{route('gyms.index')}}">
                                   <!--  <i data-feather="home"></i> -->
                                    <!-- <span class="badge badge-success float-right">1</span> -->
                                    <span> View All Gyms </span>
                                </a>
                              <a href="{{route('add-gym')}}">
                                   <!--  <i data-feather="home"></i> -->
                                    <!-- <span class="badge badge-success float-right">1</span> -->
                                    <span> Add New Gym </span>
                                </a>
                              

                            </li>
                           <!--  <li class="menu-title">Apps</li> -->
                            <li>
                                <a href="{{route('product-orders')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> View Product Orders </span>
                                </a>
                            </li>
                              <li>
                            <a href="{{route('video-orders')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> View Tutorial Orders </span>
                                </a>
                            </li>   
                            <li>
                                <a href="{{route('manage-users')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> Manage Users </span>
                                </a>
                            </li>
                              <li>
                                <a href="{{route('affiliate-partners')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> Affiliate Partner </span>
                                </a>
                            </li>
                              <li>
                                <a href="{{route('add-partner')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> Add Partner </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('tutorials.index')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> All Tutorials </span>
                                </a>
                            </li>
                             <li>
                                <a href="{{route('upload-tutorial')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> Upload Tutorials </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('product.index')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> All  Products</span>
                                </a>
                            </li>
                             <li>
                                <a href="{{route('add-product')}}">
                                 <!--    <i data-feather="calendar"></i> -->
                                    <span> Add Product </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('exercise-lib.index')}}">
                                
                                    <span>Exercise Library</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('exercise-lib.create')}}">
                                
                                    <span>Add Library</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('transactions.index')}}">
                                
                                    <span>Transactions</span>
                                </a>
                        </li>
                        </ul>
                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>
                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->