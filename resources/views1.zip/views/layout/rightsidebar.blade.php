<div class="left-side-menu" style="background-color: #F2F7FC; width: 24%;">

    <div class="sidebar-content">
        <!--- Sidemenu -->
        <div id="sidebar-menu" class="slimscroll-menu">


            <ul class="metismenu" id="menu-bar">
                <!-- <li class="menu-title">Navigation</li> -->

                <li>
                    <a href="">
                       <!--  <i data-feather="home"></i> -->
                        <!-- <span class="badge badge-success float-right">1</span> -->
                        <span><h3>How Fueled Works.</h3></span>
                    </a>
                </li>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets\ZURVOS_ASSETS\IMAGES\WEB\Icon_1.png')}}" class="img-fluid" alt="Shreyu" style=" margin-top: 21%;margin-left: 33%;">
                        </div>
                        <div class="col-lg-9">
                            <h5> Find Gym Near You & </h5>
                            <p>Take Advantage Of The Free Training Program.</p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets\ZURVOS_ASSETS\IMAGES\WEB\Icon_2.png')}}" class="img-fluid" alt="Shreyu" style=" margin-top: 21%;margin-left: 33%;">
                        </div>
                        <div class="col-lg-9">
                            <h5>Filter Your Best Match &</h5>
                            <p>Build Your Relationship With Fueled Social Media Platform.</p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets\ZURVOS_ASSETS\IMAGES\WEB\Icon_3.png')}}" class="img-fluid" alt="Shreyu" style=" margin-top: 21%;margin-left: 33%;">
                        </div>
                        <div class="col-lg-9">
                            <h5> Pay As You Go & </h5>
                            <p>Fueled, The Pioneer In Fitness Saving, Is Build To Transform Your Health.</p>
                        </div>
                    </div>
                </div>
            </ul>
            <hr>
            <ul class="metismenu" id="menu-bar">
                <!-- <li class="menu-title">Navigation</li> -->

                <li>
                    <a href="">
                       <!--  <i data-feather="home"></i> -->
                        <!-- <span class="badge badge-success float-right">1</span> -->
                        <span style=" color: darkgray">Recent Feed.</span>
                    </a>
                </li>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets/images/users/avatar-7.png')}}" class="avatar-xs rounded-circle mr-2" alt="Shreyu" style="width: 3.5rem;height: 3rem; margin-top: 39%;">
                         </div>
                        <div class="col-lg-9">
                            <h5>Congraulation!</h5>
                            <p>kevin Brace and 16 other liked your photo . 20M</p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets/images/users/avatar-7.png')}}" class="avatar-xs rounded-circle mr-2" alt="Shreyu" style="width: 3.5rem;height: 3rem; margin-top: 39%;">
                         </div>
                        <div class="col-lg-9">
                            <h5>Congraulation!</h5>
                            <p>Maggie Brown and Debbie Quiene shared yor photo. 1H</p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="{{asset('public/assets/images/users/avatar-7.png')}}" class="avatar-xs rounded-circle mr-2" alt="Shreyu" style="width: 3.5rem;height: 3rem; margin-top: 39%;">
                         </div>
                        <div class="col-lg-9">
                            <h5>Congraulation!</h5>
                            <p>Brienty tallie shred workout with you . 2H</p>
                        </div>
                    </div>
                </div>
            </ul>
        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->










                                    <div class="col">


                                           <a href="#" class="btn btn-sm mt-2 float-right" style="color: #ababb0; padding-top: 10px;">
                                        See All
                                    </a>
                                    <h6 class="header-title mb-4" style=" padding-left: 10px; padding-top: 5px">Recently Added Gyms</h6>
                                            <div id="task-list-one" class="task-list-items">

                                        <!-- Task Item -->

                                        <div class="card border mb-0">

                                            <div class="card-body p-3">

                                              <div class="dropdown float-right">

                                                    <a href="#" class="dropdown-toggle text-muted arrow-none"
                                                        data-toggle="dropdown" aria-expanded="false">
                                                        <i class="uil uil-ellipsis-v font-size-10"></i>
                                                    </a>

                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <!-- item-->
                                                        <a href="javascript:void(0);" class="dropdown-item">View more</a>
                                                        <!-- item-->
                                                        <a href="#" class="dropdown-item">Approve on Listing</a>

                                                        <!-- item-->
                                                        <a href=""
                                                            class="dropdown-item text-danger">Delete</a>
                                                    </div>
                                                </div>
                                                <h6 class="mt-0 mb-2 font-size-1">
                                                    <img src="{{asset('public/assets/images/users/avatar-9.jpg')}}"
                                                class="mr-2 rounded-circle"  height="30"  />

                                                    <a href="#" data-toggle="modal" data-target="#task-detail-modal"
                                                        class="text-body"></a>
                                                </h6>

                                                <!-- <span class="badge badge-soft-danger">High</span> -->

                                                <p class="mb-0 mt-4">
                                                    <i data-feather="map-pin"></i>
                                                       <span style="align-content: center;" class="text-muted"></span>



                                                </p>


                                        </div>
                                        <!-- TASK ITEM END -->




                                            <!-- Recent feeds -->
                                        <div class="row mt-3">
                                            <div class="col">
                                                                    <h5 class="mb-2 font-size-16" style="color: grey; margin: 20px;">RECENT FEEDS</h5>

                                                                         <hr />
                                                    <div class="media">
                                                                    <img src="{{asset('assets/images/users/avatar-7.jpg')}}" class="mr-3 avatar rounded-circle" alt="shreyu" />
                                                                    <div class="media-body">
                                                                        <h6 class="mt-0 mb-0 font-size-14 font-weight-normal">
                                                                            <a href="#" class="font-weight-bold">Kevin Bruce</a> & <span class="font-weight-bold text-primary">16 others</span> liked your photo
                                                                        </h6>
                                                                        <p class="text-muted">23M</p>
                                                                    </div>
                                                    </div>

                                                                    <hr />

                                                    <div class="media">
                                                        <img src="{{asset('assets/images/users/avatar-7.jpg')}}" class="mr-3 avatar rounded-circle" alt="shreyu" />
                                                        <div class="media-body">
                                                            <h6 class="mt-0 mb-0 font-size-14 font-weight-normal">
                                                                <a href="#" class="font-weight-bold">Kevin Bruce</a> & <span class="font-weight-bold text-primary">16 others</span> liked your photo
                                                            </h6>
                                                            <p class="text-muted">23M</p>
                                                        </div>
                                                    </div>

                                                                    <hr />

                                                    <div class="media">
                                                        <img src="{{asset('assets/images/users/avatar-7.jpg')}}" class="mr-3 avatar rounded-circle" alt="shreyu" />
                                                        <div class="media-body">
                                                            <h6 class="mt-0 mb-0 font-size-14 font-weight-normal">
                                                                <a href="#" class="font-weight-bold">Kevin Bruce</a> & <span class="font-weight-bold text-primary">16 others</span> liked your photo
                                                            </h6>
                                                            <p class="text-muted">23M</p>
                                                        </div>
                                                    </div>

                                                </div> <!-- end col -->
                                                            </div> <!-- end row -->


                                                            <!-- end comments -->
                                                        </div>
                                                </div>
                                            </div>
